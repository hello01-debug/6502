#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

using Byte = uint8_t;
using Word = uint16_t;

using u32 = uint32_t;

struct Mem
{
    static constexpr u32 MAX_MEM = 1024 * 64;
    Byte data[MAX_MEM];

    void Initialize()
    {
        for (u32 i = 0; i < MAX_MEM; i++)
        {
            data[i] = 0;
        }
    }

    Byte operator[](u32 address) const
    {
        return data[address];
    }

    Byte &operator[](u32 address)
    {
        return data[address];
    }

    void WriteWord(Word Data, Byte Address, u32& Cycles)
    {
        data[Address] = Data & 0xFF;
        data[Address + 1] = (Data >> 8);
        Cycles -= 2;
    }
};

struct CPU
{
    Word PC;
    Word SP;

    Byte A, X, Y;

    Byte C : 1;
    Byte Z : 1;
    Byte I : 1;
    Byte D : 1;
    Byte B : 1;
    Byte V : 1;
    Byte N : 1;

    void Reset(Mem &memory)
    {
        PC = 0xFFFC;
        SP = 0x0100;
        C = Z = I = D = B = V = N = 0;
        A = X = Y = 0;
        memory.Initialize();
    }

    void SetLDAStatus()
    {
        Z = (A == 0);
        N = (A & 0b10000000) > 0;
    }

    void Execute(u32 Ticks, Mem &memory)
    {
        while (Ticks > 0)
        {
            Byte Ins = Fetch(Ticks, memory);
            switch (Ins)
            {
            case INS_LDA_IM:
            {
                Byte value = Fetch(Ticks, memory);
                A = value;
                SetLDAStatus();
            }
            break;
            case INS_LDA_ZP:
            {
                Byte ZeroPageAddr = Fetch(Ticks, memory);
                A = ReadByte(Ticks, ZeroPageAddr, memory);
                SetLDAStatus();
            } break;
            case INS_LDA_ZPX:
            {
                Byte ZeroPageAddr = Fetch(Ticks, memory);
                ZeroPageAddr += X;
                Ticks--;
                A = ReadByte(Ticks, ZeroPageAddr, memory);
                SetLDAStatus();
            } break;
            case INS_JSR:
            {
                Word SubAddr = FetchWord(Ticks, memory);
                memory.WriteWord(PC - 1, SP, Ticks);
                PC = SubAddr;
                Ticks--;
            } break;
            case 0:
                break;
            default:
                printf("%x\n", (int)PC);
                printf("0x%x\n", memory[PC]);
                printf("Instruction not handled %x\n", Ins);
                break;
            }
        }
        Ticks--;
        
    }
    Byte ReadByte(u32& Ticks, Byte Address, Mem& memory)
    {
        Byte data = memory[Address];
        Ticks--;
        return data;
    }
    Byte Fetch(u32& Cycles, Mem &memory)
    {
        Byte data = memory[PC];
        PC++;
        Cycles--;
        return data;
    }

    Word FetchWord(u32& Cycles, Mem& memory)
    {
        Word data = memory[PC];
        PC++;
        data |= (memory[PC] << 8);
        Cycles -= 2;

        return data;
    }

    static constexpr Byte INS_LDA_IM = 0xA9;
    static constexpr Byte INS_LDA_ZP = 0xA5;
    static constexpr Byte INS_LDA_ZPX = 0xB5;
    static constexpr Byte INS_JSR = 0x20;
};