#include "gtest/gtest.h"
#include "../M6502Lib/src/6502.h"

class M6502Test1 : public testing::Test
{
    public:
    Mem mem;
    CPU cpu;

    virtual void SetUp()
    {
        cpu.Reset(mem);

    }

    virtual void TearDown()
    {

    }
};

TEST_F(M6502Test1, RunALittleInlineProgram)
{
    mem[0xFFFC] = CPU::INS_JSR;
    mem[0xFFFD] = 0x42;
    mem[0xFFFE] = 0x42;
    mem[0x4242] = CPU::INS_LDA_IM;
    mem[0x4243] = 0x84;
    cpu.Execute(9, mem);
}

#if 0
int main()
{
    Mem mem;
    CPU cpu;
    cpu.Reset(mem);
    mem[0xFFFC] = CPU::INS_JSR;
    mem[0xFFFD] = 0x42;
    mem[0xFFFE] = 0x42;
    mem[0x4242] = CPU::INS_LDA_IM;
    mem[0x4243] = 0x84;
    cpu.Execute(9, mem);
    printf("%d\n", (int)cpu.A);
    return 0;
}

#endif