#include "../M6502Lib/src/6502.h"

#if 0
int main()
{
    Mem mem;
    CPU cpu;
    cpu.Reset(mem);
    mem[0xFFFC] = CPU::INS_JSR;
    mem[0xFFFD] = 0x42;
    mem[0xFFFE] = 0x42;
    mem[0x4242] = CPU::INS_LDA_IM;
    mem[0x4243] = 0x84;
    cpu.Execute(9, mem);
    printf("%d\n", (int)cpu.A);
    return 0;
}

#endif

#include <cstdio>
#include "gtest/gtest.h"

#ifdef GTEST_OS_ESP8266 || GTEST_OS_ES32
#ifdef GTEST_OS_ESP8266

extern "C" {
#endif

void setup()
{
    testing::InitGoogleTest();
}

void loop() { RUN_ALL_TESTS(); }

#ifdef GTEST_OS_ESP8266
}
#endif

#else

GTEST_API_ int main(int argc, char **argv)
{
    printf("Running main() from %s\n", __FILE__);
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

#endif